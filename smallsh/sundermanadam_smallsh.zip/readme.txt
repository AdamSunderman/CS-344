To compile use: 'gcc -o smallsh smallsh.c'
To run use: ./smallsh 